---
layout: archive
title: "TESTING"
permalink: /testing/
author_profile: true
---

{% include base_path %}

{% for post in site.testing reversed %}
  {% include archive-single.html %}
{% endfor %}
