---
title: "IE 217L Manufacturing Processes Lab"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2018-spring-teaching-1
venue: "New Mexico State University, Department of Industrial Engineering"
date: 2018-01-17
location: "Las Cruces, United States of America"
---

IE manufacturing processes lab.

Class Focus
======
Add material

Student Projects
======
add material

Heading 3
======

