---
title: "Paper Title Number 1"
collection: publications
permalink: /publication/2009-10-01-paper-title-number-1
excerpt: 'This article was submitted for publication and details a Vanilla LSTM applied to a Battery This article was submitted for publication and details a Vanilla LSTM applied to a Battery time-series dataset'
date: 2020-03-01
venue: 'Journal 1'
paperurl: 'http://Tov-Nephesh.github.io/files/Article1.pdf'
citation: 'Citation pending'
---
Details pending.

[Download paper here](http://Tov-Nephesh.github.io/files/Article1.pdf)

Citation pending.
